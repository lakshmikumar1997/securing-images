package com.water.exception;

public class ConnectionException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6256717472813064682L;

	public ConnectionException() {
		// TODO Auto-generated constructor stub
	}

	public ConnectionException(String arg0) {
		super(arg0);
		
	}	

}

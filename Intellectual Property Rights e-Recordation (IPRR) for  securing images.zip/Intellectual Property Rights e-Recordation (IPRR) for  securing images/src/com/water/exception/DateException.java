package com.water.exception;

public class DateException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6256717472813064682L;

	public DateException() {
		// TODO Auto-generated constructor stub
	}

	public DateException(String arg0) {
		super(arg0);
		
	}	

}

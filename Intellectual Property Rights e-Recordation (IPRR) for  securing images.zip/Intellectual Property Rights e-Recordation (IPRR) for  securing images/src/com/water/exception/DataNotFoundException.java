package com.water.exception;

public class DataNotFoundException extends Exception{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -765691861891948892L;

	public DataNotFoundException(){
		
		
	}
	
	public DataNotFoundException(String arg0){
		
		
		
		super(arg0);
	}

}

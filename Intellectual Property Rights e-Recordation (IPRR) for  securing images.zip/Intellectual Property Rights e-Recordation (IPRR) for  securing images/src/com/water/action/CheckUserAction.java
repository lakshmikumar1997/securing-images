package com.water.action;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.water.delegate.UserDelegate;
import com.water.exception.ConnectionException;
import com.water.util.UtilConstants;

public class CheckUserAction extends HttpServlet {

	/**
			 * 
			 */
	private static final long serialVersionUID = 1L;

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter(UtilConstants._USERNAME);
		response.setContentType("text/xml");
		response.setHeader("Cache-Control", "no-cache");
		System.out.println(username);
		try {
			String user = new UserDelegate().checkUser(username);
			if (user == null) {
				response.getWriter().write(UtilConstants._USER_AVAILABLE);
			} else
				response.getWriter().write(UtilConstants._USER_NO_AVAILABLE);
		} catch (ConnectionException ce) {
			response.getWriter().write(UtilConstants._USER_NO_AVAILABLE);
		} catch (Exception e) {
			response.getWriter().write(UtilConstants._USER_NO_AVAILABLE);
		}
	}
}

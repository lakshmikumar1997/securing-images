package com.water.action;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.water.report.AdvancedDb2CsvExporter;

public class GenerateReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String table_name =request.getParameter("rtype");
		System.out.println(table_name);
		AdvancedDb2CsvExporter exporter = new AdvancedDb2CsvExporter();
		//System.out.println();
		File f =new File("e:/data/");
		f.mkdir();
	    File s =exporter.export(table_name,f.getAbsolutePath());
	    response
		.setHeader("Content-Disposition",
				"attachment; filename=\""
						+ s.getName() + "\"");
	    PrintWriter out = response.getWriter();
	    java.io.FileInputStream fileInputStream = new java.io.FileInputStream(
				s);
		int i;
		while ((i = fileInputStream.read()) != -1) {
			out.write(i);
		}
		fileInputStream.close();
		out.close();
	    
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}

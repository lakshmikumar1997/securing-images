package com.water.action;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.water.crypt.util.DecryptFileUtil;
import com.water.crypt.util.EncryptFile1Util;
import com.water.filesecurity.CryptoUtils;
import com.water.filesecurity.Decryption;

public class FileDecryptionAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		File file=new File(request.getParameter("filedecryption"));
		String key=request.getParameter("key");
		
		File file2=new File("C:/Users/admin/Desktop/Images/"+file.getName());
		
		
		/*System.out.println("before");
		CryptoUtils.encrypt(key, file, file1);
		System.out.println("Encryption completed");
		*/
		
		System.out.println("before");
		CryptoUtils.decrypt(key, file, file2);
		
		System.out.println("decryption completed");
		
		
		response.sendRedirect("FileDescription.jsp?status=Decryption Successfully Completed");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*try {
			String attach = request.getParameter("filedecryption");
			String fileType = "";
			String[] extension = attach.split("\\.");
			int i;
			for (i = 0; i < extension.length; i++) {
				fileType = extension[i];
			}
			File file = null;
			if (attach != null) {
				boolean flag = new Decryption().decryption(2, request
						.getParameter("filedecryption"), request
						.getParameter("key"));

				if (flag) {
					request.setAttribute("status",
							"File Decrypted successfully");
					request.setAttribute("filepath", "d:\\"
							+ (String) new File(attach).getName());
				} else {
					request.setAttribute("status",
							"File Not Decrypted successfully");
				}
			}
			RequestDispatcher rd = request
					.getRequestDispatcher("./FileDescription.jsp");
			rd.forward(request, response);
		} catch (IOException ioe) {
		}*/
	}
}

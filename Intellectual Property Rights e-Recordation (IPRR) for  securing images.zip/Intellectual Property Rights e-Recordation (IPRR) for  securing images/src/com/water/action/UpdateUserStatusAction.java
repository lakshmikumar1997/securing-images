package com.water.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.water.bean.ProfileTO;
import com.water.delegate.UserViewDelegate;
import com.water.util.UtilConstants;

public class UpdateUserStatusAction extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			String path="";
			boolean flag=false;
		HttpSession session = request.getSession();
		int userid = Integer.parseInt(request.getParameter("userid"));
		System.out.println("userid :" + userid);
		try {
		
			flag = new UserViewDelegate().updateUserStatus(userid);
			if (flag) {

				request.setAttribute("status", UtilConstants._USER_STATUS);
				path = UtilConstants._STATUS;

			}  else {

				request.setAttribute("status", UtilConstants._USER_STATUS_FAIL);
				path = UtilConstants._STATUS;
				
			}

		} catch (Exception e) {

			request.setAttribute("status", UtilConstants._USER_STATUS_FAIL);
			path = UtilConstants._STATUS;

		}
		RequestDispatcher rd = request.getRequestDispatcher(path);

		rd.forward(request, response);
	}
}

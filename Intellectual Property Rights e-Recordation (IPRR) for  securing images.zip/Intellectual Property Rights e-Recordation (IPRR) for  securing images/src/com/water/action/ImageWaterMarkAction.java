package com.water.action;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.ImageIcon;

public class ImageWaterMarkAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			PrintWriter out1 = response.getWriter();
			File k = new File(request.getParameter("firstImagePath"));
			System.out.println(request.getParameter("firstImagePath"));
			String image = request.getRealPath("./images")
					+ "//ImageWaterMark.jpg";
			File o = new File(image);
			BufferedImage bufferedImage1 = ImageIO.read(k);

			ImageIO.write(createResizedCopy(bufferedImage1, 500, 500),"jpg",o);
			ImageIcon photo = new ImageIcon(request.getParameter("firstImagePath"));
			BufferedImage bufferedImage = ImageIO.read(o);
			Graphics2D g2d = (Graphics2D) bufferedImage.getGraphics();
			AlphaComposite alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f);
			g2d.setComposite(alpha);

			g2d.setColor(Color.white);
			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

			g2d.setFont(new Font("Arial", Font.BOLD, 500));
			String ik1 = request.getParameter("secondImagePath");
			File k1 = new File(ik1);
			ImageIcon photo1 = new ImageIcon(ik1);
			FontMetrics fontMetrics = g2d.getFontMetrics();
			g2d.drawImage(photo1.getImage(),
					(photo.getIconWidth() - (int) photo1.getIconWidth()),
					(photo.getIconHeight() - (int) photo1.getIconHeight()),
					null);
			g2d.dispose();
			request.setAttribute("image",image);
			response.setContentType("image/jpg");
			ImageIO.write(bufferedImage,"jpg",o);
			RequestDispatcher rd = request.getRequestDispatcher("./ViewImageWaterMarkingKey.jsp");
			rd.forward(request, response);
			out1.println("yes");
		} catch (IOException ioe) {
		}
	}

	BufferedImage createResizedCopy(Image originalimage, int scaledWidth,int scaledHeight) {
		BufferedImage scaledBI = null;
		scaledBI = new BufferedImage(scaledWidth, scaledHeight,
				BufferedImage.TYPE_INT_RGB);

		Graphics2D g = scaledBI.createGraphics();
		g.setComposite(AlphaComposite.Src);
		g.drawImage(originalimage, 5,15, scaledWidth, scaledHeight, null);
		g.dispose();
		return scaledBI;

	}
}

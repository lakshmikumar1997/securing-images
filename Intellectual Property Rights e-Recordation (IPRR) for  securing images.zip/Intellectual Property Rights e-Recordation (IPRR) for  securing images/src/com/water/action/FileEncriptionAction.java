package com.water.action;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.ImageIcon;

import com.water.crypt.util.EncryptFile1Util;
import com.water.filesecurity.CryptoUtils;
import com.water.filesecurity.FileEncription;

public class FileEncriptionAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		File file=new File(request.getParameter("fileencryption"));
		
		System.out.println(getFileExtension(file));
		
		String key=request.getParameter("key");
		
		File file1=new File("C:/Users/admin/Desktop/Images/"+file.getName());
		
		System.out.println("before");
		CryptoUtils.encrypt(key, file, file1);
		System.out.println("encryption completed");
		
		response.sendRedirect("FileEncription.jsp?status=Encryption Successfully Completed");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*try {
			String attach = request.getParameter("fileencryption");

			String fileType = "";
			String[] extension = attach.split("\\.");
			int i;
			for (i = 0; i < extension.length; i++) {
				fileType = extension[i];
			}
			File file = null;
			if (attach != null) {

				boolean flag = new FileEncription().DBST(1, attach, request
						.getParameter("key"));

				if (flag) {
					request.setAttribute("status",
							"File Encrypted successfully");
					request.setAttribute("filepath", "d:\\"
							+ (String) new File(attach).getName());

				} else {
					request.setAttribute("status",
							"File Not Encrypted successfully");
				}
			}
			RequestDispatcher rd = request
					.getRequestDispatcher("./FileEncription.jsp");
			rd.forward(request, response);
		} catch (IOException ioe) {
		}*/
	}
	
	
	private static String getFileExtension(File file) {
        String fileName = file.getName();
        if(fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
        return fileName.substring(fileName.lastIndexOf(".")+1);
        else return "";
    }

}

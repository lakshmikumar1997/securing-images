package com.water.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.water.daoimpl.WaterMarkDaoImpl;
import com.water.util.UtilConstants;

public class WaterMarkImageKeyAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Long comparekey = null;
		try {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			Long key = Long.parseLong((request.getParameter("key")));
			System.out.println();
			HttpSession session = request.getSession();
			comparekey = new WaterMarkDaoImpl().textWaterMarkingKey(
					(Integer) session.getAttribute(UtilConstants._LOGINUSERID),
					(String) session.getAttribute("password"));
			if (key.equals(comparekey)) {
				request.setAttribute("image",request.getParameter("image"));
				RequestDispatcher rd = request.getRequestDispatcher("./ViewWaterMarkDoubleImage.jsp");
				rd.include(request, response);
			} else {

				String status = "Welcome"
						+ (String) session.getAttribute("user");
				RequestDispatcher rd = request
						.getRequestDispatcher("./WaterMarkTextKey.jsp?status="
								+ status);
				rd.include(request, response);
			}
		} catch (Exception e) {
		}
	}
}
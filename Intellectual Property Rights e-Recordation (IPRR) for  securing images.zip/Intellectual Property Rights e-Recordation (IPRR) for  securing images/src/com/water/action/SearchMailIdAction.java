package com.water.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.water.bean.MailsTO;
import com.water.delegate.MailDelegate;
import com.water.util.UtilConstants;

public class SearchMailIdAction extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String mailids = "";
		Vector<MailsTO> vmail = null;
		try {

			response.setContentType("text/html");
			response.setHeader("Cache-Control", "no-cache");
			if (!((request.getParameter("search").trim()).equals(""))) {
				String searchString = new MailDelegate().searchData(request
						.getParameter("search"));
				 System.out.println(searchString);
				 response.getWriter().write(searchString);
			} else {
				System.out.println("Length of string" + ("".length()));
				response.getWriter().write("");
			}

		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Length of string" + ("".length()));
			response.getWriter().write("");
		}
	}
}

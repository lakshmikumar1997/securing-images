package com.water.action;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.water.crypt.util.EmbProcess;

public class VideoAudioEmbedAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String genfile = new EmbProcess().emb(request
						.getParameter("audiovideofile"),
						request.getParameter("embedfile"));
		request.setAttribute("genfile", request.getRealPath(request
				.getParameter("embedfile")));
		System.out.println(request.getRealPath(request
				.getParameter("embedfile")));
		if (genfile != null) {
			request.setAttribute("status",
					" Water Marked Message Embed Process Completed");
			request.setAttribute("embedfile", request
					.getParameter("audiovideofile"));
		} else
			request.setAttribute("status",
					" Water Marked Message Embed Process Failed");
		RequestDispatcher rd = request
				.getRequestDispatcher("./VideoAudioWaterMark.jsp");
		rd.forward(request, response);
	}
}

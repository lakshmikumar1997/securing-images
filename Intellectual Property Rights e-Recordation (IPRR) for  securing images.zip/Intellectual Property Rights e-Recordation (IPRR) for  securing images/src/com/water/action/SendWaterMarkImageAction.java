package com.water.action;

import java.io.IOException;
import java.util.Map;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.commons.beanutils.BeanUtils;
import com.water.bean.MailsTO;
import com.water.delegate.MailDelegate;
import com.water.util.UtilConstants;

public class SendWaterMarkImageAction extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher rd = null;
		boolean flag = false;
		String path = "";
		MailsTO mail = new MailsTO();
		Map map = request.getParameterMap();
		try {
			BeanUtils.populate(mail, map);
			flag = new MailDelegate().sendWaterMarkImage(mail);
			if (flag) {
				request.setAttribute("status", UtilConstants._SEND_MAIL);
				path = UtilConstants._SEND_MAILS;
			} else {
				request.setAttribute("status", UtilConstants._SEND_MAIL_FAIL);
				path = UtilConstants._SEND_MAILS;
			}
		} catch (Exception e) {
			request.setAttribute("status", e.getMessage());
			path = UtilConstants._SEND_MAILS;
		}
		rd = request.getRequestDispatcher(path);
		rd.forward(request, response);
	}

}

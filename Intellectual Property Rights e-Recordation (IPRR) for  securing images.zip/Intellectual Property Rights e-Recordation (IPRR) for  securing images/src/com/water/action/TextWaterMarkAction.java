package com.water.action;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.ImageIcon;

import com.water.daoimpl.WaterMarkDaoImpl;
import com.water.util.UtilConstants;
import com.water.bean.WaterMarkTO;

public class TextWaterMarkAction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Long key;

		PrintWriter out1 = response.getWriter();
		String imageText = request.getParameter("markText");
		System.out.println(imageText);
		HttpSession session = request.getSession();
		try {
			key = new WaterMarkDaoImpl().textWaterMarking((Integer) session
					.getAttribute(UtilConstants._LOGINUSERID));
			if (key > 600)
				key = key % 600;
			System.out.println("path :" + request.getRealPath("./images")
					+ "//TextWaterMark.jpg");
			File k = new File(request.getParameter("imgPath"));
			File o = new File(request.getRealPath("./images")+ "//TextWaterMark.jpg");
			BufferedImage bufferedImage1 = ImageIO.read(k);
			ImageIO
					.write(createResizedCopy(bufferedImage1,390,70), "jpg",o);
			ImageIcon photo = new ImageIcon(request.getParameter("imgPath"));
			BufferedImage bufferedImage = ImageIO.read(o);
			Graphics2D g2d = (Graphics2D) bufferedImage.getGraphics();
			AlphaComposite alpha = AlphaComposite.getInstance(
					AlphaComposite.SRC_OVER, 0.5f);
			g2d.setComposite(alpha);
			g2d.setColor(Color.BLACK);
			g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
			g2d.setFont(new Font("itallic", Font.BOLD, 10));
			String watermark = request.getParameter("markText");
			System.out.println(watermark);
			FontMetrics fontMetrics = g2d.getFontMetrics();
			Rectangle2D rect = fontMetrics.getStringBounds(watermark, g2d);
			g2d.drawString(watermark, key, key);
			g2d.dispose();
			response.setContentType("image/jpg");
			ImageIO.write(bufferedImage, "jpg", o);
			RequestDispatcher rd = request
					.getRequestDispatcher("./ViewTextWaterMarkImage.jsp");
			rd.forward(request, response);
			out1.println("yes");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	BufferedImage createResizedCopy(Image originalimage, int scaledWidth,
			int scaledHeight) {
		BufferedImage scaledBI = null;
		scaledBI = new BufferedImage(scaledWidth, scaledHeight,
				BufferedImage.TYPE_INT_RGB);

		Graphics2D g = scaledBI.createGraphics();
		g.setComposite(AlphaComposite.Src);
		g.drawImage(originalimage, 0, 0, scaledWidth, scaledHeight, null);
		g.dispose();
		return scaledBI;
	}
}

package com.water.action;

import java.io.IOException;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.water.exception.ConnectionException;
import com.water.bean.ProfileTO;
import com.water.delegate.SecurityUserDelegate;
import com.water.util.UtilConstants;
import com.sun.org.apache.commons.beanutils.BeanUtils;

public class ChangePasswordAction extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2941564269120432640L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	@SuppressWarnings("unchecked")
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher requestDispatcher = null;
		boolean flag = false;
		String path = "";
		ProfileTO profileTO = new ProfileTO();
		Map map = request.getParameterMap();
		try {
			BeanUtils.populate(profileTO, map);
			flag = new SecurityUserDelegate().changePass(profileTO);
			if (flag) {
				request.setAttribute(UtilConstants._STATUS,
						UtilConstants._PASSWORD_SUCCESS);
				path = UtilConstants._USER_PASSWORD_CHANGE;
			} else {
				request.setAttribute(UtilConstants._STATUS,
						UtilConstants._PASSWORD_FAILED);
				path = UtilConstants._USER_PASSWORD_CHANGE;
			}
		} catch (ConnectionException ce) {
			throw new ServletException(UtilConstants._CONNECTION_EXCEPTION);
		} catch (Exception e) {
			request.setAttribute(UtilConstants._STATUS,
					UtilConstants._WRONG_PASS_EXCEPTION);
			path = UtilConstants._USER_PASSWORD_CHANGE;
		}
		requestDispatcher = request.getRequestDispatcher(path);
		requestDispatcher.forward(request, response);
	}
}

package com.water.util;

public class UtilConstants {

	// login

	public static final String _USERNAME = "username";
	public static final String _PASSWORD = "password";
	public static final String _ADMIN = "Admin";
	public static final String _USERNAME_AVAILABLE = "_Available";
	public static final String _PATH = "path";
	public static final String _USER = "user";
	public static final String _ADMIN_HOME = "./AdminHome.jsp";
	public static final String _USER_HOME = "./UserHome.jsp";
	public static final String _HOME = "./Home.jsp";
	public static final String _STATUS = "./Status.jsp";
	public static Object _INVALID_USER = "Invalid UserName &Password";
	public static String _LOGIN_FAILED_PAGE = "./LoginForm.jsp";
	public static String _LOGIN_PAGE = "./LoginForm.jsp";
	public static String _REGISTER_PAGE = "/RegistrationForm.jsp";
	public static final String _LOGINUSER = "user";
	public static final String _LOGINUSERID = "userid";
	public static final String _ANANIMOUSUSER = "unknownuser";
	public static final String _PASSWOED = "password";
	public static final String _ROLE = "role";
	public static final String _SERVER_BUSY = "Server Busy plz Try After Some time";
	public static final String _LOGOUT_SUCCESS = "Logout Successfully";
	public static final String _LOGOUT_FAILED = "Logout Failed";

	// user
	public static final String _USER_INFO = "Users Address Information";
	public static final String _USER_PROFILE_INFO = "Your Details";
	public static final String _VIEW_USER = "./ViewUser.jsp";
	public static final String _HOME_VIEW_USER = "HomeViewUsersAction.jsp";
	public static final String _HOME_VIEW_USER_ERROR = "HomeViewUsersAction.jsp";
	public static final String _VIEW_USER_PROFILE = "./ViewUserProfile.jsp";
	public static final String _UPDATE_USER_PROFILE = "./UpdateUserProfile.jsp";
	public static final String _NO_USER = "No USERS are available";
	public static final String _NO_USER_PROFILE = "Sorry Server down pls try later.....";
	public static final String _INVALIED_ENTRY = "User are not Available ";
	public static final String _USER_STATUS = "Users status updated successfully";
	public static final String _USER_STATUS_FAIL = "Users status updation Failed";
	public static final String _NO_ANIMAL_TYPE = "No AnimalTO Types Found";
	public static final String _USER_DELETE_SUCCESS = " Users Deleted Successfully";
	public static final String _USER_DELETE_FAIL = "No user deleted";

	// registration
	public static final String _REGISTERED_SUCCESS = "user Registered Successfully";
	public static final String _REGISTERED_FAIL = "user Registration Failed";
	public static final String _INVALID_ENTRIES = "invalid Entries";
	public static final String _VIEW_ALL__USER = "./ViewUser.jsp";
	public static final String _UPDATE_SUCCESS = " Updated Successfully";
	public static final String _UPDATE_FAIL = "Updation Fail";
	public static final String _USER_AVAILABLE = "Available";
	public static final String _WORKER_REGISTRATION = "./WorkerRegistrationForm.jsp";
	public static final String _USER_NO_AVAILABLE = "Already Exists";

	// logout
	public static final String _LOGOUT = "LoginForm.jsp?status=logout successfully";

	// login
	public static final String _ADMIN_PASSWORD_CHANGE = "./AdminChangepassword.jsp";
	public static final String _PASSWORD_SUCCESS = "Password Changed Successfully";
	public static final String _PASSWORD_FAILED = "Password Changing Failed";
	public static final String _USER_PASSWORD_CHANGE = "./Changepassword.jsp";
	public static final String _RECOVER_PASSWORD = "./Recoverpassword.jsp";
	public static final String _NEW_PASSWORD = "./NewPasswordAction.jsp";
	public static final String _RECOVER_PASSWORD_SUCCESS = "Enter New password";
	public static final String _RECOVER_PASSWORD_FAILED = "Password Recovering is Failed";

	// mails
	public static final String _COMPOSE_MAIL = "./ComposeMailAction.jsp";
	public static final String _SEND_IMAGE_MAIL = "./SendWaterMarkImage.jsp";
	public static final String _NO_CONTACTS = "No Contacts";
	public static final String _SEND_MAIL = "Mail Sended Successfully";
	public static final String _SEND_MAILS = "./Status.jsp";
	public static final String _SEND_MAIL_FAIL = " Mail Sending Fail";
	public static final String _MAILS = "Your MailsTO";
	public static final String _MAIL_BOX = "./MailBox.jsp";
	public static final String _MAIL_WATERMARKIMAGE_BOX = "./WaterMarkImageFileBox.jsp";
	public static final String _MAIL_BOX_FAIL = "Mail box is empty";
	public static final String _MAIL_MESSAGE = "Message Body";
	public static final String __MAIL_MESSAGE_FAIL = "Error at showing message body";
	public static final String _MAIL_BODY = "./Mailbody.jsp";
	public static final String _MAIL_DELETE_SUCCESS = "Mails Deleted Successfully";
	public static final String _WATERMARK_IMAGE_DELETE_SUCCESS = "Image Deleted Successfully";
	public static final String _MAILS_DELETE_FAIL = "Mails not deleted";
	public static final String _WATERMARK_IMAGE_DELETE_FAIL = "Mails not deleted";

	// Exceptions messages
	public static final String _CONNECTION_EXCEPTION = "server busy please try again";
	public static final String _WRONG_PASS_EXCEPTION = "Invalid Entries or Enter old Password properly";
}

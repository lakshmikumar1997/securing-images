package com.water.daoi;



import java.util.Vector;

import com.water.bean.ProfileTO;


public interface SecurityDaoI {
	
	
	 public Vector<ProfileTO> loginCheck(ProfileTO pro);
	 public boolean changePass(ProfileTO pro);
	 public boolean changeQuestion(ProfileTO pro);
	 public boolean passwordRecovery(ProfileTO pro);
		public boolean forgetPass(ProfileTO pro);
		
}

package com.water.daoi;

import java.util.Vector;

import com.water.bean.ProfileTO;

public interface UserViewDaoI {
	 public Vector<ProfileTO> viewUser(String path,String user,String status);
	 public boolean updateUserStatus(int userid);
	 public Vector<ProfileTO> viewUser(String user,String path);
	 public boolean deleteUser(int userid);
} 

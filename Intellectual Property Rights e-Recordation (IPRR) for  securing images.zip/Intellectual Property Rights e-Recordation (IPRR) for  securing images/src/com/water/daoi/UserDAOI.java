package com.water.daoi;

import java.io.FileNotFoundException;

import com.water.exception.ConnectionException;
import com.water.bean.ProfileTO;

public interface UserDAOI {
	 public boolean insertNewUser(ProfileTO pro) throws FileNotFoundException,ConnectionException;
	 public boolean updateUser(ProfileTO pro) throws FileNotFoundException,ConnectionException;
	 public String checkUser(String userid);
}

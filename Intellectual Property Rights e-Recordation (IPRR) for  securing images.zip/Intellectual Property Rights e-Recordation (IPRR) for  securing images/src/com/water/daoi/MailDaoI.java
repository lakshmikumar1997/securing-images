package com.water.daoi;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.Vector;

import com.water.bean.MailsTO;
import com.water.exception.ConnectionException;

public interface MailDaoI {
	public boolean sendMail(MailsTO mail) throws ConnectionException,
			SQLException;

	public Vector<MailsTO> mailContacts() throws ConnectionException,
			SQLException;

	public Vector<MailsTO> viewMails(MailsTO mail) throws ConnectionException,
			SQLException;

	public Vector<MailsTO> viewWaterMarkImageFiles(MailsTO mail)
			throws ConnectionException, SQLException;

	public boolean insestAttachement(int userid, String attachmentfile)
			throws ConnectionException, SQLException, FileNotFoundException;

	public boolean deleteMails(int msgid, String mailbox)
			throws ConnectionException, SQLException;

	public boolean deleteWaterMarkImageFiles(int msgid, String mailbox)
			throws ConnectionException, SQLException;

	public Vector<MailsTO> viewMail(int messageid, String mailbox)
			throws ConnectionException, SQLException;

	public boolean sendWaterMarkImage(MailsTO mail) throws ConnectionException,
			SQLException;

	public boolean deleteTips(int messageidx) throws ConnectionException,
			SQLException;

	public boolean sendMailAttachment(MailsTO mail) throws ConnectionException,
			SQLException;

	public String searchData(String parameter);
}
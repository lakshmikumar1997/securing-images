package com.water.serviceimpl;

import java.io.FileNotFoundException;
import java.util.Vector;

import com.water.bean.ProfileTO;
import com.water.daoi.UserViewDaoI;
import com.water.daoimpl.UserViewDaoImpl;
import com.water.exception.ConnectionException;
import com.water.servicei.UserViewServiceI;

public class UserViewServiceImpl implements UserViewServiceI{
	 
	
	boolean flag=false;
	Vector<ProfileTO> vpro=null;
	UserViewDaoI sdaoi=new UserViewDaoImpl();
	 public Vector<ProfileTO> viewUser(String path,String user,String status) throws FileNotFoundException,ConnectionException{
				 
		 vpro=sdaoi.viewUser( path,user,status);

		 return vpro;
	
	 }		
	 
	 public boolean updateUserStatus(int userid) throws ConnectionException{
		 
		 flag=sdaoi.updateUserStatus(userid);

		 return flag;
	
	 }	
	 public Vector<ProfileTO> viewUser(String user,String path) throws FileNotFoundException,ConnectionException{
		 
		 vpro=sdaoi.viewUser(user,path);

		 return vpro;
	
	 }	
	 
	 public boolean  deleteUser(int userid) throws ConnectionException{
		 
		 flag=sdaoi. deleteUser(userid);

		 return flag;
	
	 }	
	
}

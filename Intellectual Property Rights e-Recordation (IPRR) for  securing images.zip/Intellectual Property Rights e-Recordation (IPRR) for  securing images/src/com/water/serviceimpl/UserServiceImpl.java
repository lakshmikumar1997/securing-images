package com.water.serviceimpl;

import java.io.FileNotFoundException;


import com.water.bean.ProfileTO;
import com.water.daoi.UserDAOI;
import com.water.daoimpl.UserDaoImpl;
import com.water.exception.ConnectionException;
import com.water.exception.DataNotFoundException;
import com.water.servicei.UserServiceI;

public class UserServiceImpl implements UserServiceI{

	
	
	UserDAOI rdao=new UserDaoImpl();
	boolean flag=false;
	public boolean changePass(ProfileTO pf)
			throws ConnectionException {
		// TODO Auto-generated method stub
		return false;
	}
	public boolean changeQuestion(ProfileTO pf)
			throws ConnectionException {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean insertNewUser(ProfileTO pf) throws FileNotFoundException,ConnectionException {
		flag=rdao.insertNewUser(pf);
			return flag;
		
		
	}
	public boolean updateUser(ProfileTO pf) throws FileNotFoundException,ConnectionException {
		flag=rdao.updateUser(pf);
			return flag;
		
		
	}
	public boolean logout(String loginid)
			throws ConnectionException {
		// TODO Auto-generated method stub
		return false;
	}
	
	public String passwordRecovery(ProfileTO pf) throws DataNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}
	public String checkUser(String userName) {
		userName=rdao.checkUser(userName);
		 
		 
			
		 
		return userName;
	}

	
	
	/*
	
	 
	 

	*/

}

package com.water.serviceimpl;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.Vector;

import com.water.bean.MailsTO;
import com.water.bean.ProfileTO;
import com.water.daoi.MailDaoI;
import com.water.daoimpl.MailDaoImpl;
import com.water.exception.ConnectionException;
import com.water.servicei.MailServiceI;

public class MailServiceImpl implements MailServiceI {

	boolean flag = false;
	Vector<ProfileTO> vpro = null;
	MailDaoI mdaoi = new MailDaoImpl();

	public Vector<MailsTO> mailContacts() throws ConnectionException,
			SQLException {
		return mdaoi.mailContacts();
	}

	public boolean sendMail(MailsTO mail) throws ConnectionException,
			SQLException {
		flag = mdaoi.sendMail(mail);
		return flag;
	}

	public Vector<MailsTO> viewWaterMarkImageFiles(MailsTO mail)
			throws ConnectionException, SQLException {
		return mdaoi.viewWaterMarkImageFiles(mail);
	}

	public Vector<MailsTO> viewMails(MailsTO mail) throws ConnectionException,
			SQLException {
		return mdaoi.viewMails(mail);
	}

	public boolean insestAttachement(int userid, String attachmentfile)
			throws ConnectionException, SQLException, FileNotFoundException {
		flag = mdaoi.insestAttachement(userid, attachmentfile);
		return flag;
	}

	public boolean deleteMails(int msgid, String mailbox)
			throws ConnectionException, SQLException {
		flag = mdaoi.deleteMails(msgid, mailbox);
		return flag;
	}

	public boolean deleteWaterMarkImageFiles(int msgid, String mailbox)
			throws ConnectionException, SQLException {
		flag = mdaoi.deleteWaterMarkImageFiles(msgid, mailbox);
		return flag;
	}

	public Vector<MailsTO> viewMail(int messageid, String mailbox)
			throws ConnectionException, SQLException {
		return mdaoi.viewMail(messageid, mailbox);
	}

	public boolean sendWaterMarkImage(MailsTO mail) throws ConnectionException,
			SQLException {
		flag = mdaoi.sendWaterMarkImage(mail);
		return flag;
	}

	public boolean deleteTips(int msgid) throws ConnectionException,
			SQLException {
		flag = mdaoi.deleteTips(msgid);
		return flag;
	}

	public boolean sendMailAttachment(MailsTO mail) throws ConnectionException,
			SQLException {
		return mdaoi.sendMailAttachment(mail);

	}

	public String searchData(String parameter) {
		// TODO Auto-generated method stub
		return mdaoi.searchData(parameter);
	}
}

package com.water.serviceimpl;


import java.util.Vector;

import com.water.bean.ProfileTO;
import com.water.daoi.SecurityDaoI;
import com.water.daoimpl.SecurityDaoImpl;
import com.water.exception.ConnectionException;
import com.water.exception.LoginException;
import com.water.servicei.SecurityServiceI;

public class SecurityServiceImpl implements SecurityServiceI{
	
	String logintype="";
	boolean flag=false;
	Vector<ProfileTO> vpro=null;
	SecurityDaoI sdaoi=new SecurityDaoImpl();
	

	 public Vector<ProfileTO> loginCheck(ProfileTO pro)throws LoginException,ConnectionException{
		 vpro=sdaoi.loginCheck(pro);
		 return vpro;
	 } public boolean changePass(ProfileTO pro)throws ConnectionException{
			 flag=sdaoi.changePass(pro);
		 if(flag==false){
			 
			 throw new ConnectionException();
				 
		 }
		 
		 
		 return flag;
	
	 }
		 public boolean changeQuestion(ProfileTO rto)throws ConnectionException{
			 
	        flag=sdaoi.changeQuestion(rto);
			 
			 if(flag==false)
				{
					
					throw new ConnectionException();
					
				}
				return flag;
			 
			 
		 }	 
		 public boolean passwordRecovery(ProfileTO rto)throws ConnectionException{
			 
			 flag=sdaoi.passwordRecovery(rto);
				return flag;
			 
			 
		 }
		 public boolean forgetPass(ProfileTO pro)throws ConnectionException{
				
			 
			 flag=sdaoi.forgetPass(pro);
			 
			 if(flag==false){
				 
				 throw new ConnectionException();
					 
			 }
			 
			 
			 return flag;
		
		 }
		
}

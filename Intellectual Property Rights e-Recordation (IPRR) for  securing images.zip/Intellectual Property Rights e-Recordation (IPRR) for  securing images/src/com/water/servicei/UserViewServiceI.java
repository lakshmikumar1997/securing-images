package com.water.servicei;

import java.io.FileNotFoundException;
import java.util.Vector;

import com.water.bean.ProfileTO;
import com.water.exception.ConnectionException;

public interface UserViewServiceI {
	public Vector<ProfileTO> viewUser(String path, String user, String status)
			throws FileNotFoundException, ConnectionException;

	public boolean updateUserStatus(int userid) throws ConnectionException;

	public Vector<ProfileTO> viewUser(String user, String path)
			throws FileNotFoundException, ConnectionException;

	public boolean deleteUser(int userid) throws ConnectionException;
}

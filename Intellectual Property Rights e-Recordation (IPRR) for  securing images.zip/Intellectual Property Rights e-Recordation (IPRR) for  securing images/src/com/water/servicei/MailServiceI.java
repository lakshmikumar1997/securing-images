package com.water.servicei;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.Vector;
import com.water.bean.MailsTO;
import com.water.exception.ConnectionException;

public interface MailServiceI {
	// public boolean insertTime(String time,int employeeid) throws
	// ConnectionException,SQLException ;
	public Vector<MailsTO> mailContacts() throws ConnectionException,
			SQLException;

	public boolean sendMail(MailsTO mail) throws ConnectionException,
			SQLException;

	public boolean sendWaterMarkImage(MailsTO mail) throws ConnectionException,
			SQLException;

	public Vector<MailsTO> viewMails(MailsTO mail) throws ConnectionException,
			SQLException;

	public Vector<MailsTO> viewWaterMarkImageFiles(MailsTO mail)
			throws ConnectionException, SQLException;

	public boolean deleteMails(int msgid, String mailbox)
			throws ConnectionException, SQLException;

	public boolean deleteWaterMarkImageFiles(int msgid, String mailbox)
			throws ConnectionException, SQLException;

	public boolean insestAttachement(int userid, String attachmentfile)
			throws ConnectionException, SQLException, FileNotFoundException;

	public Vector<MailsTO> viewMail(int messageid, String mailbox)
			throws ConnectionException, SQLException;

	public boolean deleteTips(int msgid) throws ConnectionException,
			SQLException;

	public boolean sendMailAttachment(MailsTO mail) throws ConnectionException, SQLException;

	public String searchData(String parameter);
}
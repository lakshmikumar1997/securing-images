package com.water.servicei;

import java.io.FileNotFoundException;

import com.water.bean.ProfileTO;
import com.water.exception.ConnectionException;


public interface UserServiceI {	
public boolean insertNewUser(ProfileTO pf) throws FileNotFoundException,ConnectionException;
public boolean updateUser(ProfileTO pf) throws FileNotFoundException,ConnectionException;
public String checkUser(String userName)throws ConnectionException;

}

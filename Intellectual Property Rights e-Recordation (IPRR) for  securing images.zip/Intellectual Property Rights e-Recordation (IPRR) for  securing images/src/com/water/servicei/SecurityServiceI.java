package com.water.servicei;



import java.util.Vector;

import com.water.bean.ProfileTO;
import com.water.exception.ConnectionException;
import com.water.exception.LoginException;

public interface SecurityServiceI {
	
	 public Vector<ProfileTO>loginCheck(ProfileTO pro)throws LoginException,ConnectionException;
	 public boolean changePass(ProfileTO pro)throws ConnectionException; 
	 public boolean changeQuestion(ProfileTO pro)throws ConnectionException;
	 public boolean passwordRecovery(ProfileTO pro)throws ConnectionException;
		public boolean forgetPass(ProfileTO pro) throws ConnectionException;
		
}

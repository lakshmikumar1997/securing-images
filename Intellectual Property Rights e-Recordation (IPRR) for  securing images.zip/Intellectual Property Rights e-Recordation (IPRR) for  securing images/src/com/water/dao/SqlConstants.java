package com.water.dao;

public class SqlConstants {

	// ex public static final String
	// _ADD_STATE="insert into state values((select nvl(max(stateid),100)+1 from state),?)";

	public static final String _CHECK_USER = "select l.useridref,l.logintype from logindetails l,userdetails u where loginid=? and password=? and u.status='Active' and u.userid=l.useridref";
	public static final String _CHANGE_PASSWORD = "update logindetails set password=? where loginid=? and password=?";
	public static final String _CHANGE_QUESTION = "update userdetails set forgotpwquestion=?,forgotpwanswer=? where (select loginid from logindetails l,userdetails u where loginid='a' and l.useridref=u.userid )=?";
	public static final String _RECOVER_PASSWORD = "select password from logindetails l,userdetails u where l.loginid=? and u.forgotpwquestion=? and u.forgotpwanswer=?";
	public static final String _NEW_PASSWORD = "update logindetails set password=? where loginid=?";
	public static final String _VIEW_USER = "select u.userid,u.firstname,u.emailid,u.gender,u.faxno,"
			+ "u.photograph,u.status,p.phoneno,a.houseno,a.STREET,a.city,a.DISTRICT,a.STATE,a.COUNTRY,a.PINCODE,"
			+ "l.logintype,l.loginid from userdetails u,phones p,addresses a, logindetails l "
			+ "where u.userid=p.useridref and u.userid=a.useridref and p.useridref=a.useridref and status=? "
			+ "and l.logintype=? and u.userid=l.useridref and p.useridref=l.useridref and a.useridref=l.useridref";
	public static final String _VIEW_USER_PROFILE = "select u.userid,u.firstname,u.lastname,u.dob,u.emailid,u.faxno,u.photograph,p.phonetype,p.phoneno,a.addresstype,a.houseno,a.STREET,a.city,a.DISTRICT,a.STATE,a.COUNTRY,a.PINCODE from userdetails u,phones p,addresses a, logindetails l where u.userid=p.useridref and u.userid=a.useridref and p.useridref=a.useridref and l.loginid=? and u.userid=l.useridref and p.useridref=l.useridref and a.useridref=l.useridref";
	public static final String _UPDATE_USER_STATUS = "update userdetails set status='Active' where userid=?";
	public static final String _DELETE_USER = "update userdetails set status='Request' where userid=?";
	// mails
	public static final String _MAIL_CONTACTS = "select userid,(select loginid from logindetails where userdetails.userid=logindetails.useridref) from userdetails";
	public static final String _SEND_MAIL = "insert into INBOX_MAILS values((select nvl(max(messageid),100)+1 from INBOX_MAILS),?,?,?,?,sysdate)";
	public static final String _SEND_MAIL1 = "insert into OUTBOX_MAILS values((select nvl(max(messageid),100)+1 from OUTBOX_MAILS),?,?,?,?,sysdate)";
	public static final String _SEND_ATTACHMENT = "insert into INBOX_Attachment values((select nvl(max(messageid),100)+1 from INBOX_attachment),?,?,?,?,?,sysdate,?)";
	public static final String _SEND_ATTACHMENT1 = "insert into OUTBOX_attachment values((select nvl(max(messageid),100)+1 from OUTBOX_attachment),?,?,?,?,?,sysdate,?)";

	public static final String _VIEW_OUT_MAILS = "select * from OUTBOX_MAILS where frommailid=?";
	public static final String _VIEW_OUT_MAIL = "select * from OUTBOX_MAILS where messageid=?";
	public static final String _VIEW_IMAGE_FILES_OUTBOX = "select * from OUTBOX_Attachment where frommailid=?";
	public static final String _VIEW_IMAGE_FILES_INBOX = "select * from OUTBOX_Attachment where tomailid=?";

	public static final String _VIEW_IN_MAILS = "select * from INBOX_MAILS where tomailid=?";
	public static final String _VIEW_IN_MAIL = "select * from INBOX_MAILS where messageid=?";
	public static final String _VIEW_MAILID = "select loginid from logindetails where useridref=?";
	public static final String _DELETE_MAIL = "delete OUTBOX_MAILS where messageid=?";
	public static final String _DELETE_MAIL1 = "delete INBOX_MAILS where messageid=?";
	public static final String _DELETE_WATERMARK_ATTACHMENT = "delete OUTBOX_Attachment where messageid=?";
	public static final String _DELETE_WATERMARK_ATTACHMENT1 = "delete INBOX_attachment where messageid=?";
	public static final String _TIPS_SUGGESTION = "delete TIPS_SUGGESTIONS where tipsid=?";
	public static final String _ATTACH_FILE = "insert into Attachment values((select max(attachmentid) from attachment),(select nvl(max(attachmentid),100)+1 from attachment),?,?)";

}
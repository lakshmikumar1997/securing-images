// Decompiled by Jad v1.5.8f. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   WaterMarkDaoImpl.java

package com.water.daoimpl;

import com.water.dao.AbstractDataAccessObject;
import com.water.exception.ConnectionException;
import java.io.PrintStream;
import java.sql.*;

public class WaterMarkDaoImpl extends AbstractDataAccessObject
{

    public WaterMarkDaoImpl()
    {
        con = null;
        ps = null;
    }

    public Long textWaterMarkingKey(int userid, String password)
        throws SQLException
    {
        Long key = null;
        try
        {
            System.out.println("haiiiiiii");
            con = getConnection();
            ps = con.prepareStatement("select faxno from userdetails where userid=?");
            ps.setInt(1, userid);
            rs = ps.executeQuery();
            if(rs.next())
                key = Long.valueOf(rs.getLong(1));
            else
                System.out.println("invalid user name or password");
      
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        if(rs != null)
            rs.close();
        if(ps != null)
            ps.close();
        if(con != null)
            con.close();
    
        return key;
    }

    public long textWaterMarking(int userid)
        throws ConnectionException
    {
        long key = 50L;
        con = getConnection();
        try
        {
            PreparedStatement pst = con.prepareStatement((new StringBuilder("select faxno from userdetails where userid='")).append(userid).append("' ").toString());
            ResultSet rs = pst.executeQuery();
            if(rs.next())
                key = rs.getLong(1);
        }
        catch(SQLException ex)
        {
            ex.printStackTrace();
            System.out.println(ex);
            flag = false;
            try
            {
                con.rollback();
            }
            catch(SQLException sqlexception) { }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            flag = false;
            try
            {
                con.rollback();
            }
            catch(SQLException sex)
            {
                sex.printStackTrace();
                System.out.println(sex);
            }
        }
      
        try
        {
            if(con != null)
                con.close();
        }

        catch(SQLException sqlexception2) { }
        return key;
    }

    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    String ans;
    boolean flag;
}

package com.water.daoimpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Vector;

import com.water.exception.ConnectionException;
import com.water.util.LoggerManager;
import com.water.bean.ProfileTO;
import com.water.dao.AbstractDataAccessObject;
import com.water.dao.SqlConstants;
import com.water.daoi.UserDAOI;
import com.water.util.DateWrapper;

public class UserDaoImpl implements UserDAOI {
	Connection con;
	PreparedStatement pstmt, pstmt1;
	Statement stmt;
	ResultSet rs, rs1;

	public UserDaoImpl() {

		con = AbstractDataAccessObject.getConnection();

	}

	public String checkUser(String userName) {
		String user = null;
		System.out.println("username" + userName);
		try

		{
			con.setAutoCommit(true);
			CallableStatement cstmt = con
					.prepareCall("{ call loginidavailablity(?,?) }");
			cstmt.setString(1, userName);
			cstmt.registerOutParameter(2, Types.VARCHAR);
			cstmt.execute();
			user = cstmt.getString(2);

		} catch (SQLException ex) {
			ex.printStackTrace();
			LoggerManager.writeLogSevere(ex);
			user = null;
		} catch (Exception e) {
			LoggerManager.writeLogSevere(e);
			user = null;
		} finally {
			try {
				con.close();
			} catch (SQLException se) {
				LoggerManager.writeLogWarning(se);
			} catch (Exception e) {
				LoggerManager.writeLogWarning(e);
			}
		}
		return user;
	}

	public boolean insertNewUser(ProfileTO pro) throws FileNotFoundException {
		boolean flag = false;
		String firstname = pro.getFirstName();
		System.out.println("firstname  :" + firstname);
		String lastname = pro.getLastName();
		System.out.println("lastname- " + lastname);
		String birthdate = DateWrapper.parseDate(pro.getBirthdate());
		System.out.println("birthdate-" + birthdate);
		String squest = pro.getSquest();
		// System.out.println("squest-"+squest);
		if (squest == null) {
			squest = pro.getOwnquest();
			System.out.println("squest" + squest);
		}
		String sqansw = pro.getSecrete();
		System.out.println("sqansw :" + sqansw);

		String fax = pro.getFax();
		System.out.println("fax-" + fax);

		String email = pro.getEmail();
		System.out.println("email-" + email);

		String gender = pro.getGender();
		System.out.println("gender-" + gender);
		String addresstype = pro.getAddressType();
		System.out.println("addresstype-" + addresstype);
		String houseno = pro.getHouseNo();
		System.out.println("houseno:" + houseno);
		String street = pro.getStreet();
		System.out.println("street-" + street);
		String city = pro.getCity();
		System.out.println("city-" + city);
		String district = pro.getDistrict();
		System.out.println("district-" + district);
		String state = pro.getState();
		System.out.println("state-" + state);
		String country = pro.getCountry();
		System.out.println("country" + country);
		String pin = pro.getPin();

		System.out.println("pin" + pin);
		String phonetype = pro.getPhoneType();
		System.out.println("phonetype-" + phonetype);
		String phoneno = pro.getPhoneNo();
		System.out.println("phoneno-" + phoneno);
		String logintype = pro.getLoginType();
		System.out.println("logintype-" + logintype);
		String username = pro.getUserName();
		System.out.println("username-" + username);
		String password = pro.getPassword();
		System.out.println("password-" + password);
		String photo = pro.getPhoto();

		try {
			System.out.println("photo=" + photo);
			File f = new File(photo);
			FileInputStream fis = new FileInputStream(f);
			System.out.println("fole=" + f.length());

			CallableStatement cstmt = con
					.prepareCall("{call insertprocedure(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			cstmt.setBinaryStream(1, fis, (int) f.length());
			cstmt.setString(2, firstname);
			cstmt.setString(3, lastname);
			cstmt.setString(4, birthdate);
			cstmt.setString(5, squest);
			cstmt.setString(6, sqansw);
			cstmt.setString(7, email);
			cstmt.setString(8, fax);
			cstmt.setString(9, gender);
			cstmt.setString(10, username);
			cstmt.setString(11, password);
			cstmt.setString(12, logintype);
			cstmt.setString(13, addresstype);
			cstmt.setString(14, houseno);
			cstmt.setString(15, street);
			cstmt.setString(16, city);
			cstmt.setString(17, district);
			cstmt.setString(18, state);
			cstmt.setString(19, country);
			cstmt.setString(20, pin);
			cstmt.setString(21, phoneno);
			cstmt.setString(22, phonetype);

			int i = cstmt.executeUpdate();
			if (i == 1) {
				flag = true;
			} else {
				flag = false;

			}
			con.close();
		} catch (SQLException e) {

			System.out.println(e.toString());
			if (e
					.toString()
					.equalsIgnoreCase(
							"java.sql.SQLException: [Microsoft][ODBC driver for Oracle][Oracle]ORA-12571: TNS:packet writer failure")) {
				flag = true;
				System.out.println("n===" + flag);
			}
			System.out.println(e);

		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			try {
				con.rollback();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return flag;
	}

	public boolean updateUser(ProfileTO pro) throws FileNotFoundException {
		boolean flag = false;
		String username = pro.getUserName();
		String firstname = pro.getFirstName();
		String lastname = pro.getLastName();
		String birthdate = DateWrapper.parseDate(pro.getBirthdate());
		String photo = pro.getPhoto1();
				System.out.println("hsi"+photo);
		if (photo.equals("")) {
			photo = pro.getPhoto();
		}
		String fax = pro.getFax();
		String email = pro.getEmail();
		String houseno = pro.getHouseNo();
		String street = pro.getStreet();
		String city = pro.getCity();
		String district = pro.getDistrict();
		String state = pro.getState();
		String country = pro.getCountry();
		String pin = pro.getPin();
		String phoneno = pro.getPhoneNo();

		try {
			System.out.println("photo=" + photo);
			File f = new File(photo);
			FileInputStream fis = new FileInputStream(f);
			System.out.println("fole=" + f.length());

			CallableStatement cstmt = con
					.prepareCall("{call updateprocedure(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			cstmt.setBinaryStream(1, fis, (int) f.length());
			cstmt.setString(2, firstname);
			cstmt.setString(3, lastname);
			cstmt.setString(4, birthdate);
			cstmt.setString(5, email);
			cstmt.setString(6, fax);
			cstmt.setString(7, username);
	
			cstmt.setString(8, houseno);
			System.out.println("houseno :"+houseno);
			cstmt.setString(9, street);
			System.out.println("street :"+street);
			cstmt.setString(10, city);
			System.out.println("city :"+city);
			cstmt.setString(11, district);
			System.out.println("district :"+district);
			cstmt.setString(12, state);
			System.out.println("state :"+state);
			cstmt.setString(13, country);
			System.out.println("country :"+country);
			cstmt.setString(14, pin);
			System.out.println("pin :"+pin);
			cstmt.setString(15, phoneno);


			int i = cstmt.executeUpdate();
			if (i == 1) {
				flag = true;
				con.commit();
			} else {
				flag = false;

			}
			con.close();
		} catch (SQLException e) {
			System.out.println(e.toString());
			if (e
					.toString()
					.equalsIgnoreCase(
							"java.sql.SQLException: [Microsoft][ODBC driver for Oracle][Oracle]ORA-12571: TNS:packet writer failure")) {
				flag = true;
				System.out.println("n===" + flag);
			}
			System.out.println(e);

		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
			try {
				con.rollback();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return flag;
	}

	public Vector<ProfileTO> viewUser(String user,String path) {
		
		Vector<ProfileTO> v = new Vector<ProfileTO>();
		ProfileTO pro = null;
		v.clear();
		try {
			pstmt = con
					.prepareStatement(SqlConstants._VIEW_USER_PROFILE);
			pstmt.setString(1, user);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
					pro = new ProfileTO();
				pro.setUserid(rs.getInt(1));
				pro.setFirstName(rs.getString(2));
				pro.setLastName(rs.getString(3));
				pro.setBirthdate(DateWrapper.parseDate(rs.getDate(4)));
				pro.setEmail(rs.getString(5));
				pro.setFax(rs.getString(6));
				Blob b = rs.getBlob(7);
				byte b1[] = b.getBytes(1, (int) b.length());
				path=path + "/" + rs.getInt(1)+ ".jpg";
				System.out.println("path  :"+path);
				OutputStream fout = new FileOutputStream(path);
				fout.write(b1);
				pro.setPhoto(path);
				pro.setPhoneType(rs.getString(8));
				pro.setPhoneNo(rs.getString(9));
				pro.setAddressType(rs.getString(10));
				pro.setHouseNo(rs.getString(11));
				pro.setStreet(rs.getString(12));
				pro.setCity(rs.getString(13));
				pro.setDistrict(rs.getString(14));
				pro.setState(rs.getString(15));
				pro.setCountry(rs.getString(16));
				pro.setPin(rs.getString(17));
				v.add(pro);
			}
		} catch (SQLException se) {
			LoggerManager.writeLogWarning(se);
		} catch (Exception e) {
			LoggerManager.writeLogWarning(e);
		} 
		finally {
			try {
				con.close();
			} catch (SQLException se) {
				LoggerManager.writeLogWarning(se);
			}
		}
		return v;
	}
}

package com.water.daoimpl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;


import com.water.bean.ProfileTO;
import com.water.daoi.SecurityDaoI;
import com.water.dao.AbstractDataAccessObject;
import com.water.dao.SqlConstants;


public class SecurityDaoImpl extends AbstractDataAccessObject implements SecurityDaoI {

	Connection con;
	PreparedStatement pstmt;
	Statement stmt;
	ResultSet rs;
	boolean flag = false;

	public SecurityDaoImpl() {

		con =getConnection();
	}

	public Vector<ProfileTO> loginCheck(ProfileTO pro) {
		
		String logintype = "";
		int userid;
		ProfileTO profileTO=null;
		Vector<ProfileTO> vpro=new Vector<ProfileTO>();
		try {

			pstmt = con.prepareStatement(SqlConstants._CHECK_USER);
			String username = pro.getUserName();
			System.out.println("in Security DAO class.....uname is" + username);
			String password = pro.getPassword();
			System.out.println("in Security DAO class.....password is"
					+ password);
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				profileTO=new ProfileTO();
				profileTO.setUserid(rs.getInt(1));
				profileTO.setLoginType(rs.getString(2));
				System.out.println("in result set login type is........."
						+ logintype);
			vpro.add(profileTO);
			}

		} catch (SQLException e) {
		e.printStackTrace();
			System.out.println("Exception raised" + e);
		}
		return vpro;
	}
	public boolean changePass(ProfileTO pf) {
		try {
			String newpass = pf.getNewpassword();
			System.out.println(" security dao new pass " + newpass);
			String user = pf.getUserName();
			System.out.println("security dao user :" + user);
			String oldpass = pf.getOldpassword();
			System.out.println("security dao oldpass :" + oldpass);
			pstmt = con.prepareStatement(SqlConstants._CHANGE_PASSWORD);
			pstmt.setString(1, newpass);
			pstmt.setString(2, user);
			pstmt.setString(3, oldpass);
			int c = pstmt.executeUpdate();
			if (c > 0) {
				flag = true;
				con.commit();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

	public boolean changeQuestion(ProfileTO pf) {
		boolean flag = true;
		try {
			String question = pf.getSquest();
			System.out.println("in Dao qusetion is..." + question);
			String ans = pf.getSecrete();
			System.out.println("in Dao ans is..." + ans);
			String loginid = pf.getUserName();
			System.out.println("in Dao loginid is..." + loginid);

			pstmt = con.prepareStatement(SqlConstants._CHANGE_QUESTION);
			pstmt.setString(1, question);
			pstmt.setString(2, ans);
			pstmt.setString(3, loginid);

			int update = pstmt.executeUpdate();
			if (update > 0) {
				con.commit();
			} else {
				flag = false;
				con.rollback();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			flag = false;
			try {
				con.rollback();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

		finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return flag;
	}

	public boolean passwordRecovery(ProfileTO pf) {

		try {

			String question = pf.getSquest();
			if (question == null)
				question = pf.getOwnquest();
			String ans = pf.getSecrete();
			String loginid = pf.getUserName();

			pstmt = con.prepareStatement(SqlConstants._RECOVER_PASSWORD);
			pstmt.setString(1, loginid);
			pstmt.setString(2, question);
			pstmt.setString(3, ans);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

	public boolean forgetPass(ProfileTO pf) {
		boolean flag = true;

		try {

			String pwd = pf.getPassword();
			System.out.println("in Dao pwd is..." + pwd);
			String loginid = pf.getUserName();
			System.out.println("in Dao loginid is..." + loginid);

			pstmt = con.prepareStatement(SqlConstants._NEW_PASSWORD);
			pstmt.setString(1, pwd);
			pstmt.setString(2, loginid);

			int update = pstmt.executeUpdate();
			if (update > 0) {
				con.commit();
			} else {
				flag = false;
				con.rollback();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			flag = false;
			try {
				con.rollback();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

		finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return flag;
	}

	
}
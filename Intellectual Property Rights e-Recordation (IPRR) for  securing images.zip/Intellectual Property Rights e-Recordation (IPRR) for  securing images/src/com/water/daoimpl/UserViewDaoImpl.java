package com.water.daoimpl;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import com.water.bean.ProfileTO;
import com.water.dao.AbstractDataAccessObject;
import com.water.dao.SqlConstants;
import com.water.daoi.UserViewDaoI;
import com.water.util.DateWrapper;
import com.water.util.LoggerManager;

public class UserViewDaoImpl implements UserViewDaoI {
	
	Connection con;
	PreparedStatement pstmt;
	Statement stmt;
	ResultSet rs;
	boolean flag = false;
	

	public UserViewDaoImpl() {
		con = AbstractDataAccessObject.getConnection();
	}
public Vector<ProfileTO> viewUser(String realpath, String user,String status) {
		
		Vector<ProfileTO> v = new Vector<ProfileTO>();
		ProfileTO pro = null;
		v.clear();
		try {
			pstmt = con
					.prepareStatement(SqlConstants._VIEW_USER);
			pstmt.setString(1, status);pstmt.setString(2, user);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
					String path=realpath;
				pro = new ProfileTO();
				pro.setUserid(rs.getInt(1));
				pro.setFirstName(rs.getString(2));
				System.out.println("haiiiiiii" + rs.getString(2));
				pro.setEmail(rs.getString(3));
				pro.setGender(rs.getString(4));
				pro.setFax(rs.getString(5));
				Blob b = rs.getBlob(6);
				byte b1[] = b.getBytes(1, (int) b.length());
				path=path + "/" + rs.getInt(1)+ ".jpg";
				System.out.println("path  :"+path);
				OutputStream fout = new FileOutputStream(path);
				fout.write(b1);
				pro.setPhoto(path);
				pro.setStatus(rs.getString(7));
				pro.setPhoneNo(rs.getString(8));
				pro.setHouseNo(rs.getString(9));
				pro.setStreet(rs.getString(10));
				pro.setCity(rs.getString(11));
				pro.setDistrict(rs.getString(12));
				pro.setState(rs.getString(13));
				pro.setCountry(rs.getString(14));
				pro.setPin(rs.getString(15));
				pro.setLoginType(rs.getString(16));
				pro.setUserName(rs.getString(17));
			v.add(pro);
			}
		} catch (SQLException se) {
			LoggerManager.writeLogWarning(se);
		} catch (Exception e) {
			LoggerManager.writeLogWarning(e);
		} 
		finally {
			try {
				con.close();
			} catch (SQLException se) {
				LoggerManager.writeLogWarning(se);
			}
		}
		return v;
	}
public boolean updateUserStatus(int userid) {
		try {
		pstmt = con
				.prepareStatement(SqlConstants._UPDATE_USER_STATUS);
		pstmt.setInt(1, userid);
		int i = pstmt.executeUpdate();
		if (i>0) {
				flag=true;
		}
	} catch (SQLException se) {
		LoggerManager.writeLogWarning(se);
	} catch (Exception e) {
		LoggerManager.writeLogWarning(e);
	} 
	finally {
		try {
			con.close();
		} catch (SQLException se) {
			LoggerManager.writeLogWarning(se);
		}
	}
	return flag;
}
public Vector<ProfileTO> viewUser(String user,String path) {
	
	Vector<ProfileTO> v = new Vector<ProfileTO>();
	ProfileTO pro = null;
	v.clear();
	try {
		pstmt = con
				.prepareStatement(SqlConstants._VIEW_USER_PROFILE);
		pstmt.setString(1, user);
		ResultSet rs = pstmt.executeQuery();
		while (rs.next()) {
				pro = new ProfileTO();
			pro.setUserid(rs.getInt(1));
			pro.setFirstName(rs.getString(2));
			pro.setLastName(rs.getString(3));
			pro.setBirthdate(DateWrapper.parseDate(rs.getDate(4)));
			pro.setEmail(rs.getString(5));
			pro.setFax(rs.getString(6));
			Blob b = rs.getBlob(7);
			byte b1[] = b.getBytes(1, (int) b.length());
			path=path + "/" + rs.getInt(1)+ ".jpg";
			System.out.println("path  :"+path);
			OutputStream fout = new FileOutputStream(path);
			fout.write(b1);
			pro.setPhoto(path);
			pro.setPhoneType(rs.getString(8));
			pro.setPhoneNo(rs.getString(9));
			pro.setAddressType(rs.getString(10));
			pro.setHouseNo(rs.getString(11));
			pro.setStreet(rs.getString(12));
			pro.setCity(rs.getString(13));
			pro.setDistrict(rs.getString(14));
			pro.setState(rs.getString(15));
			pro.setCountry(rs.getString(16));
			pro.setPin(rs.getString(17));
			v.add(pro);
		}
	} catch (SQLException se) {
		LoggerManager.writeLogWarning(se);
	} catch (Exception e) {
		LoggerManager.writeLogWarning(e);
	} 
	finally {
		try {
			con.close();
		} catch (SQLException se) {
			LoggerManager.writeLogWarning(se);
		}
	}
	return v;
}
public boolean deleteUser(int userid) {
	try {
	pstmt = con
			.prepareStatement(SqlConstants._DELETE_USER);
	pstmt.setInt(1, userid);
	int i = pstmt.executeUpdate();
	if (i>0) {
			flag=true;
	}
} catch (SQLException se) {
	LoggerManager.writeLogWarning(se);
} catch (Exception e) {
	LoggerManager.writeLogWarning(e);
} 
finally {
	try {
		con.close();
	} catch (SQLException se) {
		LoggerManager.writeLogWarning(se);
	}
}
return flag;
}
}

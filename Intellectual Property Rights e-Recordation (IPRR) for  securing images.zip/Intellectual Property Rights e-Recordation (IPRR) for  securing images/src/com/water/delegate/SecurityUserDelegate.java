package com.water.delegate;

import java.util.Vector;

import com.water.exception.ConnectionException;
import com.water.exception.LoginException;
import com.water.bean.ProfileTO;
import com.water.servicei.SecurityServiceI;
import com.water.serviceimpl.SecurityServiceImpl;

public class SecurityUserDelegate {

	SecurityServiceI ssi = new SecurityServiceImpl();
	Vector<ProfileTO> vpro = null;

	public Vector<ProfileTO> loginCheck(ProfileTO pro) throws LoginException,
			ConnectionException {

		vpro = ssi.loginCheck(pro);
		return vpro;

	}

	public boolean changePass(ProfileTO pro) throws ConnectionException {

		return ssi.changePass(pro);
	}

	public boolean changeQuestion(ProfileTO pro) throws ConnectionException {

		return ssi.changeQuestion(pro);
	}

	public boolean passwordRecovery(ProfileTO pro) throws ConnectionException {

		return ssi.passwordRecovery(pro);
	}

	public boolean forgetPass(ProfileTO pro) throws ConnectionException {

		return ssi.forgetPass(pro);
	}

}

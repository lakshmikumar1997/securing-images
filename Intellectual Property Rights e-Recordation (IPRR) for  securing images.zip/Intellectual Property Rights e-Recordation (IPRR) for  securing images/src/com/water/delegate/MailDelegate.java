package com.water.delegate;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.Vector;
import com.water.bean.MailsTO;
import com.water.bean.ProfileTO;
import com.water.exception.ConnectionException;
import com.water.servicei.MailServiceI;
import com.water.serviceimpl.MailServiceImpl;

public class MailDelegate {
	MailServiceI usi = new MailServiceImpl();
	boolean flag = false;
	Vector<ProfileTO> vpro = null;

	public Vector<MailsTO> mailContacts() throws ConnectionException,
			SQLException {
		return usi.mailContacts();
	}

	public boolean sendMail(MailsTO mail) throws ConnectionException,
			SQLException {
		flag = usi.sendMail(mail);
		return flag;
	}

	public boolean sendMailAttachment(MailsTO mail) throws ConnectionException,
			SQLException {
		flag = usi.sendMailAttachment(mail);
		return flag;
	}

	public boolean sendWaterMarkImage(MailsTO mail) throws ConnectionException,
			SQLException {
		flag = usi.sendWaterMarkImage(mail);
		return flag;
	}

	public Vector<MailsTO> viewMails(MailsTO mail) throws ConnectionException,
			SQLException {
		return usi.viewMails(mail);
	}

	public Vector<MailsTO> viewWaterMarkImageFiles(MailsTO mail)
			throws ConnectionException, SQLException {
		return usi.viewWaterMarkImageFiles(mail);
	}

	public boolean deleteMails(int msgid, String mailbox)
			throws ConnectionException, SQLException {
		flag = usi.deleteMails(msgid, mailbox);
		return flag;
	}

	public boolean deleteWaterMarkImageFiles(int msgid, String mailbox)
			throws ConnectionException, SQLException {
		flag = usi.deleteWaterMarkImageFiles(msgid, mailbox);
		return flag;
	}

	public boolean insestAttachement(int userid, String attachmentfile)
			throws ConnectionException, SQLException, FileNotFoundException {
		flag = usi.insestAttachement(userid, attachmentfile);
		return flag;
	}

	public Vector<MailsTO> viewMail(int messageid, String mailbox)
			throws ConnectionException, SQLException {
		return usi.viewMail(messageid, mailbox);
	}

	public boolean deleteTips(int messageid) throws ConnectionException,
			SQLException {
		return usi.deleteTips(messageid);
	}

	public String searchData(String parameter) {
		// TODO Auto-generated method stub
		return usi.searchData(parameter);
	}

}

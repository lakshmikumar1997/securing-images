package com.water.delegate;

import java.io.FileNotFoundException;
import java.util.Vector;

import com.water.exception.ConnectionException;
import com.water.bean.ProfileTO;
import com.water.servicei.UserViewServiceI;
import com.water.serviceimpl.UserViewServiceImpl;

public class UserViewDelegate {

	UserViewServiceI uvsi = new UserViewServiceImpl();

	public Vector<ProfileTO> viewUser(String path, String user, String status)
			throws FileNotFoundException, ConnectionException {

		return uvsi.viewUser(path, user, status);
	}

	public Vector<ProfileTO> viewUser(String user, String path)
			throws FileNotFoundException, ConnectionException {

		return uvsi.viewUser(user, path);
	}

	public boolean updateUserStatus(int userid) throws ConnectionException {

		return uvsi.updateUserStatus(userid);
	}

	public boolean deleteUser(int userid) throws ConnectionException {

		return uvsi.deleteUser(userid);
	}
}

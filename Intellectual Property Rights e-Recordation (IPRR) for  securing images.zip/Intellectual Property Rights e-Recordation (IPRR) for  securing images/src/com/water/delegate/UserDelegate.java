package com.water.delegate;

import java.io.FileNotFoundException;

import com.water.exception.ConnectionException;
import com.water.bean.ProfileTO;
import com.water.servicei.UserServiceI;
import com.water.servicei.UserViewServiceI;
import com.water.serviceimpl.UserServiceImpl;
import com.water.serviceimpl.UserViewServiceImpl;

public class UserDelegate {

	UserServiceI usi = new UserServiceImpl();
	UserViewServiceI uvsi=new UserViewServiceImpl();
	public boolean insertNewUser(ProfileTO pf) throws FileNotFoundException,
			ConnectionException {

		return usi.insertNewUser(pf);

	}
	public boolean updateUser(ProfileTO pf) throws FileNotFoundException,
	ConnectionException {

return usi.updateUser(pf);

}


	public String checkUser(String userName) throws ConnectionException {

		return usi.checkUser(userName);

	}



}
